/// <reference types="vite/client" />
import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Play, Plus, Search, Home, Compass, Library, 
  Settings, Bell, Star, Clock, ChevronRight, Check,
  MonitorPlay, Film, Edit2, Trash2, ExternalLink, X, CheckCheck
} from 'lucide-react';

// --- TYPES ---
type TrackStatus = 'Watching' | 'On-Hold' | 'Completed' | 'Plan to Watch';
type TrackType = 'Series' | 'Movie';

interface TrackItem {
  id: string;
  title: string;
  type: TrackType;
  status: TrackStatus;
  currentSeason?: number;
  totalSeasons?: number;
  currentEp: number;
  totalEps?: number;
  image?: string;
  lastUpdated: string;
  description?: string;
  genres?: string[];
  releaseDate?: string;
  history?: { date: string; ep: number }[];
}

// --- MOCK DATA ---
const HERO_MOVIE = {
  id: "550",
  title: "INTERSTELLAR",
  subtitle: "2014 • LATEST RELEASE",
  description: "The adventures of a group of explorers who make use of a newly discovered wormhole to surpass the limitations on human space travel and conquer the vast distances involved in an interstellar voyage.",
  image: "https://image.tmdb.org/t/p/original/rAiYTfKGqDCRIIqo664sY9XZIvQ.jpg",
  tags: ["Adventure", "Drama", "Sci-Fi"],
  rating: "8.4"
};

const WATCHING = [
  { 
    id: 1399, 
    title: "Game of Thrones", 
    image: "https://image.tmdb.org/t/p/w500/1XS1oqL89opfnbLl8WnZY1O1uJx.jpg", 
    epCurrent: 5, 
    epTotal: 10, 
    nextEpTitle: "The Door",
    timeLeft: "45m remaining"
  },
  { 
    id: 1396, 
    title: "Breaking Bad", 
    image: "https://image.tmdb.org/t/p/w500/ggFHVNu6YYI5L9pCfOacjizRGt.jpg", 
    epCurrent: 12, 
    epTotal: null, 
    nextEpTitle: "Ozymandias",
    timeLeft: "Just Released"
  },
];

const TRENDING = [
  { id: 157336, title: "Interstellar", image: "https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg", score: "8.4" },
  { id: 27205, title: "Inception", image: "https://image.tmdb.org/t/p/w500/oYuLEt3zVCKq57qu2F8dT7NIa6f.jpg", score: "8.4" },
  { id: 155, title: "The Dark Knight", image: "https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg", score: "8.5" },
  { id: 550, title: "Fight Club", image: "https://image.tmdb.org/t/p/w500/pB8BM7pdSp6B6Ih7QZ4DrQ3PmJK.jpg", score: "8.4" },
  { id: 603, title: "The Matrix", image: "https://image.tmdb.org/t/p/w500/f89U3ADr1oiB1s9GkdPOEpXUk5H.jpg", score: "8.2" },
];

const INITIAL_LIBRARY: TrackItem[] = [
  {
    id: "101",
    title: "Money Heist",
    type: "Series",
    status: "Completed",
    currentSeason: 4,
    totalSeasons: 4,
    currentEp: 6,
    totalEps: 6,
    lastUpdated: "2 days ago",
    image: "https://image.tmdb.org/t/p/w500/reEMJA1uzscCbkpeRFeKIAO6QVG.jpg",
    description: "Eight thieves take hostages and lock themselves in the Royal Mint of Spain as a criminal mastermind manipulates the police to carry out his plan.",
    genres: ["Action", "Crime", "Mystery"],
    releaseDate: "May 2, 2017"
  },
  {
    id: "102",
    title: "The Walking Dead",
    type: "Series",
    status: "Watching",
    currentSeason: 11,
    totalSeasons: 11,
    currentEp: 20,
    totalEps: 24,
    lastUpdated: "Just now",
    image: "https://image.tmdb.org/t/p/w500/xf9wuDcqlUPTXNdcaUKvd11aZ8v.jpg",
    description: "Sheriff's deputy Rick Grimes awakens from a coma to find a post-apocalyptic world dominated by flesh-eating zombies.",
    genres: ["Action", "Drama", "Sci-Fi"],
    releaseDate: "Oct 31, 2010"
  },
  {
    id: "103",
    title: "Stranger Things",
    type: "Series",
    status: "Watching",
    currentSeason: 4,
    totalSeasons: 4,
    currentEp: 6,
    totalEps: 9,
    lastUpdated: "4 hours ago",
    image: "https://image.tmdb.org/t/p/w500/49WJfeN0moxb9IPfGn8x02zBv5j.jpg",
    description: "When a young boy vanishes, a small town uncovers a mystery involving secret experiments, terrifying supernatural forces, and one strange little girl.",
    genres: ["Drama", "Fantasy", "Sci-Fi"],
    releaseDate: "Jul 15, 2016"
  },
  {
    id: "104",
    title: "Oppenheimer",
    type: "Movie",
    status: "Plan to Watch",
    currentEp: 0,
    totalEps: 1,
    lastUpdated: "1 week ago",
    image: "https://image.tmdb.org/t/p/w500/8Gxv8gSFCU0XGDykEGv7zR1n2ua.jpg",
    description: "The story of J. Robert Oppenheimer's role in the development of the atomic bomb during World War II.",
    genres: ["Drama", "History"],
    releaseDate: "Jul 19, 2023"
  }
];

import LoginPage from './components/LoginPage';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [activeNav, setActiveNav] = useState('My List'); // Defaulting to My List to show off the tracker
  const [selectedAnime, setSelectedAnime] = useState<any>(null);
  const [selectedLibraryItem, setSelectedLibraryItem] = useState<TrackItem | null>(null);
  const [activeModalTab, setActiveModalTab] = useState<'Details' | 'History'>('Details');
  
  const [heroAnimes, setHeroAnimes] = useState<any[]>([HERO_MOVIE]);
  const [trendingAnime, setTrendingAnime] = useState<any[]>(TRENDING);
  const [heroIndex, setHeroIndex] = useState(0);
  const [isHeroHovered, setIsHeroHovered] = useState(false);

  const [topMovies, setTopMovies] = useState<any[]>([]);
  const [topSeries, setTopSeries] = useState<any[]>([]);
  const [recommendedMovies, setRecommendedMovies] = useState<any[]>([]);
  const [recommendedSeries, setRecommendedSeries] = useState<any[]>([]);
  const [topAnimes, setTopAnimes] = useState<any[]>([]);
  const [apiKeyMissing, setApiKeyMissing] = useState(false);
  
  useEffect(() => {
    const fetchMedia = async () => {
      let fetchedAnimes: any[] = [];
      // Fetch anime via Jikan API unconditionally
      try {
        const jikanRes = await fetch('https://api.jikan.moe/v4/top/anime?filter=airing&limit=10');
        const jikanData = await jikanRes.json();
        if (jikanData && jikanData.data) {
          fetchedAnimes = jikanData.data.map((anime: any) => ({
            id: anime.mal_id.toString(),
            title: anime.title_english || anime.title,
            image: anime.images?.webp?.large_image_url || anime.images?.jpg?.large_image_url,
            heroImage: anime.trailer?.images?.maximum_image_url || anime.trailer?.images?.large_image_url || anime.images?.webp?.large_image_url || anime.images?.jpg?.large_image_url,
            score: anime.score?.toString() || "N/A",
            tags: (anime.genres || []).map((g: any) => g.name).slice(0, 3).concat(['Anime']),
            description: anime.synopsis,
            type: anime.type === 'Movie' ? 'Movie' : 'Series',
            totalEps: anime.episodes || undefined,
            rating: anime.score?.toString() || "N/A",
            subtitle: anime.status === 'Currently Airing' ? 'CURRENTLY Airing' : 'LATEST RELEASE'
          }));
          setTopAnimes(fetchedAnimes);
        }
      } catch (err) {
        console.error("Error fetching anime from API:", err);
      }

      const TMDB_API_KEY = import.meta.env.VITE_TMDB_API_KEY;
      if (!TMDB_API_KEY) {
        setApiKeyMissing(true);
        return;
      }

      setApiKeyMissing(false);
      const IMG_BASE = 'https://image.tmdb.org/t/p/w500';
      const IMG_ORIGINAL = 'https://image.tmdb.org/t/p/original';

      const mapTMDBItem = (item: any, forceType?: 'Movie' | 'Series') => ({
        id: item.id.toString(),
        title: item.title || item.name || item.original_title,
        image: item.poster_path ? `${IMG_BASE}${item.poster_path}` : 'https://placehold.co/400x600/1a1a2e/ffffff?text=No+Image',
        heroImage: item.backdrop_path ? `${IMG_ORIGINAL}${item.backdrop_path}` : (item.poster_path ? `${IMG_ORIGINAL}${item.poster_path}` : 'https://placehold.co/1920x1080/1a1a2e/ffffff?text=No+Image'),
        score: item.vote_average ? item.vote_average.toFixed(1).toString() : "N/A",
        tags: [forceType || (item.media_type === 'tv' ? 'Series' : 'Movie'), 'Trending'],
        description: item.overview || "No description available.",
        type: forceType || (item.media_type === 'tv' ? 'Series' : 'Movie'),
        rating: item.vote_average ? item.vote_average.toFixed(1).toString() : "N/A",
        subtitle: (item.release_date || item.first_air_date) ? new Date(item.release_date || item.first_air_date).getFullYear().toString() : 'RECENT'
      });

      try {
        let fetchedTrending: any[] = [];
        let topMoviesList: any[] = [];
        let topSeriesList: any[] = [];
        
        // Trending
        let res = await fetch(`https://api.themoviedb.org/3/trending/all/day?api_key=${TMDB_API_KEY}`);
        let data = await res.json();
        if (data && data.results) {
          fetchedTrending = data.results.map((i: any) => mapTMDBItem(i));
          if (fetchedTrending.length > 0) {
            setTrendingAnime(fetchedTrending);
          }
        }

        // Top Movies
        res = await fetch(`https://api.themoviedb.org/3/movie/top_rated?api_key=${TMDB_API_KEY}`);
        data = await res.json();
        if (data && data.results) {
          topMoviesList = data.results.map((i: any) => mapTMDBItem(i, 'Movie'));
          setTopMovies(topMoviesList);
        }

        // Top Series
        res = await fetch(`https://api.themoviedb.org/3/tv/top_rated?api_key=${TMDB_API_KEY}`);
        data = await res.json();
        if (data && data.results) {
          topSeriesList = data.results.map((i: any) => mapTMDBItem(i, 'Series'));
          setTopSeries(topSeriesList);
        }

        // Recommended Movies
        res = await fetch(`https://api.themoviedb.org/3/movie/popular?api_key=${TMDB_API_KEY}`);
        data = await res.json();
        if (data && data.results) setRecommendedMovies(data.results.map((i: any) => mapTMDBItem(i, 'Movie')));

        // Recommended Series
        res = await fetch(`https://api.themoviedb.org/3/tv/popular?api_key=${TMDB_API_KEY}`);
        data = await res.json();
        if (data && data.results) setRecommendedSeries(data.results.map((i: any) => mapTMDBItem(i, 'Series')));
        
        // MIX FOR HERO: 1 Top Anime, 1 Top Movie, 1 Top Series, 2 Trending
        const heroMix: any[] = [];
        if (fetchedAnimes.length > 0) heroMix.push({ ...fetchedAnimes[0], image: fetchedAnimes[0].heroImage || fetchedAnimes[0].image });
        if (topMoviesList.length > 0) heroMix.push({ ...topMoviesList[0], image: topMoviesList[0].heroImage });
        if (topSeriesList.length > 0) heroMix.push({ ...topSeriesList[0], image: topSeriesList[0].heroImage });
        
        fetchedTrending.forEach(item => {
           if (heroMix.length < 5 && !heroMix.find(m => m.id === item.id)) {
              heroMix.push({ ...item, image: item.heroImage || item.image });
           }
        });
        
        if (heroMix.length > 0) {
           setHeroAnimes(heroMix);
        }
        
      } catch (err) {
        console.error("Error fetching media from TMDB API:", err);
      }
    };
    
    fetchMedia();
  }, []);

  useEffect(() => {
    if (isHeroHovered || heroAnimes.length <= 1) return;
    
    const timeout = setTimeout(() => {
      setHeroIndex(prev => (prev + 1) % heroAnimes.length);
    }, 4500);
    
    return () => clearTimeout(timeout);
  }, [isHeroHovered, heroAnimes.length, heroIndex]);

  const heroAnime = heroAnimes[heroIndex] || heroAnimes[0];

  // User Profile
  const [userProfile, setUserProfile] = useState({
    name: 'Mia Winters',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop'
  });
  
  // Library State
  const [library, setLibrary] = useState<TrackItem[]>(INITIAL_LIBRARY);
  const [libraryFilter, setLibraryFilter] = useState<'All' | TrackStatus>('All');
  const [genreFilter, setGenreFilter] = useState<string>('All');
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const [isBulkMode, setIsBulkMode] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  
  // Add Modal State
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newItemParams, setNewItemParams] = useState<Partial<TrackItem>>({
    type: 'Series',
    status: 'Watching',
    currentSeason: 1,
    currentEp: 0
  });

  const availableGenres = useMemo(() => {
    const genres = new Set<string>();
    library.forEach(item => {
      item.genres?.forEach(g => genres.add(g));
    });
    return Array.from(genres).sort();
  }, [library]);

  const searchSuggestions = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const query = searchQuery.toLowerCase();
    
    // Search titles
    const titles = library
      .filter(item => item.title.toLowerCase().includes(query))
      .map(item => ({ label: item.title, type: 'Title' as const }));
      
    // Search genres
    const genres = Array.from(new Set(library.flatMap(item => item.genres || [])))
      .filter(g => g.toLowerCase().includes(query))
      .map(g => ({ label: g, type: 'Genre' as const }));
      
    // Search status
    const statuses = ['Watching', 'Completed', 'On-Hold', 'Plan to Watch']
      .filter(s => s.toLowerCase().includes(query))
      .map(s => ({ label: s, type: 'Status' as const }));

    const combined = [...titles, ...genres, ...statuses];
    // Remove duplicates by label
    const unique = combined.filter((v, i, a) => a.findIndex(t => t.label === v.label) === i);
    return unique.slice(0, 6);
  }, [searchQuery, library]);

  const filteredLibrary = useMemo(() => {
    return library.filter(item => {
      const matchesFilter = libraryFilter === 'All' || item.status === libraryFilter;
      const searchLower = searchQuery.toLowerCase();
      const matchesSearch = !searchLower || 
        item.title.toLowerCase().includes(searchLower) || 
        item.status.toLowerCase().includes(searchLower) || 
        (item.genres && item.genres.some(g => g.toLowerCase().includes(searchLower)));
      const matchesGenre = genreFilter === 'All' || item.genres?.includes(genreFilter);
      return matchesFilter && matchesSearch && matchesGenre;
    });
  }, [library, libraryFilter, genreFilter, searchQuery]);

  const statusColors: Record<TrackStatus, string> = {
    'Watching': 'text-blue-400 bg-blue-400/10 border-blue-400/20',
    'Completed': 'text-green-400 bg-green-400/10 border-green-400/20',
    'On-Hold': 'text-yellow-400 bg-yellow-400/10 border-yellow-400/20',
    'Plan to Watch': 'text-zinc-400 bg-zinc-400/10 border-zinc-400/20',
  };

  const statusIndicatorColors: Record<TrackStatus, string> = {
    'Watching': 'bg-blue-500',
    'Completed': 'bg-green-500',
    'On-Hold': 'bg-yellow-500',
    'Plan to Watch': 'bg-zinc-500',
  };

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemParams.title) return;
    
    const newItem: TrackItem = {
      id: Math.random().toString(36).substr(2, 9),
      title: newItemParams.title,
      type: newItemParams.type as TrackType,
      status: newItemParams.status as TrackStatus,
      currentSeason: newItemParams.currentSeason,
      totalSeasons: newItemParams.totalSeasons,
      currentEp: newItemParams.currentEp || 0,
      totalEps: newItemParams.totalEps,
      lastUpdated: "Just now"
    };

    setLibrary([newItem, ...library]);
    setIsAddModalOpen(false);
    setNewItemParams({ type: 'Series', status: 'Watching', currentSeason: 1, currentEp: 0 });
  };

  const updateItemProgress = (id: string, newEp: number) => {
    const now = new Date().toISOString();
    setLibrary(lib => lib.map(item => {
      if (item.id === id) {
        let newStatus = item.status;
        if (item.totalEps && newEp >= item.totalEps && (!item.totalSeasons || item.currentSeason === item.totalSeasons)) {
          newStatus = 'Completed';
        } else if (newStatus === 'Plan to Watch' && newEp > 0) {
          newStatus = 'Watching';
        }
        const historyItem = { date: now, ep: newEp };
        const newHistory = item.history ? [historyItem, ...item.history] : [historyItem];
        return { ...item, currentEp: newEp, status: newStatus, lastUpdated: 'Just now', history: newHistory };
      }
      return item;
    }));
    
    if (selectedLibraryItem && selectedLibraryItem.id === id) {
      setSelectedLibraryItem(prev => {
        if (!prev) return prev;
        const historyItem = { date: now, ep: newEp };
        return {
          ...prev,
          currentEp: newEp,
          history: prev.history ? [historyItem, ...prev.history] : [historyItem]
        };
      });
    }
  };

  if (!isAuthenticated) {
    return <LoginPage onLogin={() => setIsAuthenticated(true)} />;
  }

  return (
    <div className="flex h-screen w-full bg-[#09090b] text-white overflow-hidden relative font-sans">
      {/* Background glow for atmosphere */}
      <div className="glow-bg bg-fuchsia-600/20 w-[600px] h-[600px] top-[-200px] left-[-200px]" />
      <div className="glow-bg bg-blue-600/20 w-[500px] h-[500px] bottom-[-200px] right-[-100px]" />

      {/* --- SIDEBAR --- */}
      <nav className="hidden lg:flex flex-col w-24 xl:w-64 border-r border-white/5 bg-black/20 backdrop-blur-3xl z-40 py-8 px-4 justify-between transition-all duration-300">
        <div className="flex flex-col items-center xl:items-start gap-8 w-full">
          {/* Logo */}
          <div className="w-12 h-12 xl:w-full flex items-center xl:px-4 gap-3 bg-gradient-to-br from-fuchsia-500 to-indigo-600 rounded-xl xl:bg-transparent xl:from-transparent text-white justify-center">
            <Play className="w-6 h-6 fill-white drop-shadow-md xl:hidden" />
            <div className="hidden xl:flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-fuchsia-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-fuchsia-500/20">
                <Play className="w-5 h-5 fill-white" />
              </div>
              <span className="font-bold tracking-widest text-xl text-transparent bg-clip-text bg-gradient-to-r from-fuchsia-400 to-indigo-400">
                NEXA
              </span>
            </div>
          </div>

          {/* Links */}
          <div className="flex flex-col gap-4 w-full mt-4">
            <NavItem icon={<Home />} label="Home" isActive={activeNav === 'Home'} onClick={() => setActiveNav('Home')} />
            <NavItem icon={<Library />} label="My Library" isActive={activeNav === 'My List'} onClick={() => setActiveNav('My List')} />
          </div>
        </div>

        <div className="flex flex-col items-center xl:items-start gap-4 w-full">
           <NavItem icon={<Settings />} label="Settings" isActive={activeNav === 'Settings'} onClick={() => setActiveNav('Settings')} />
           <div className="w-12 h-12 xl:w-full flex items-center gap-3 mt-4 xl:px-4 cursor-pointer hover:bg-white/5 p-2 rounded-xl transition-colors">
             <img 
               src={userProfile.avatar} 
               className="w-10 h-10 rounded-full object-cover border border-white/20"
               alt="User profile"
             />
             <div className="hidden xl:flex flex-col">
               <span className="font-medium text-sm text-zinc-100 leading-tight">{userProfile.name}</span>
               <span className="text-xs text-fuchsia-400">Pro Member</span>
             </div>
           </div>
        </div>
      </nav>

      {/* --- MAIN CONTENT --- */}
      <main className="flex-1 h-full overflow-y-auto overflow-x-hidden hide-scrollbar relative">
        {/* Top bar */}
        <header className="absolute top-0 left-0 w-full z-50 p-6 flex justify-between items-center bg-gradient-to-b from-black/70 to-transparent pointer-events-none">
          <div className="relative w-full max-w-sm pointer-events-auto">
            <div className="glass-panel flex items-center gap-3 px-4 py-2.5 rounded-full w-full">
              <Search className="w-4 h-4 text-zinc-400" />
              <input 
                type="text" 
                placeholder="Search library by title, genre, or status..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => setIsSearchFocused(true)}
                onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)}
                className="bg-transparent border-none outline-none text-sm w-full placeholder:text-zinc-500 text-zinc-100"
              />
            </div>
            {isSearchFocused && searchSuggestions.length > 0 && (
              <div className="absolute top-full mt-2 w-full glass-panel rounded-xl overflow-hidden border border-white/10 shadow-2xl z-50">
                {searchSuggestions.map((suggestion, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setSearchQuery(suggestion.label);
                      if (activeNav !== 'My List') setActiveNav('My List');
                    }}
                    className="w-full text-left px-4 py-3 flex items-center justify-between hover:bg-white/10 transition-colors"
                  >
                    <span className="font-medium text-sm text-zinc-200">{suggestion.label}</span>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-fuchsia-400/80 bg-fuchsia-400/10 px-2 py-0.5 rounded border border-fuchsia-400/20">{suggestion.type}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="flex items-center gap-4 pointer-events-auto">
            {activeNav === 'My List' && (
              <button 
                onClick={() => setIsAddModalOpen(true)}
                className="hidden md:flex items-center gap-2 bg-white/10 hover:bg-white/20 border border-white/10 text-white px-5 py-2 rounded-xl text-sm font-semibold transition-colors"
              >
                <Plus className="w-4 h-4" /> Add
              </button>
            )}
            <button className="w-10 h-10 rounded-full glass-panel flex flex-shrink-0 items-center justify-center relative hover:bg-white/10 transition-colors">
              <Bell className="w-5 h-5 text-zinc-300" />
              <span className="absolute top-2.5 right-3 w-1.5 h-1.5 rounded-full bg-fuchsia-500"></span>
            </button>
             <button className="w-10 h-10 rounded-full glass-panel flex flex-shrink-0 items-center justify-center relative hover:bg-white/10 transition-colors">
              <span className="text-zinc-300 font-bold text-xs font-mono">RP</span>
            </button>
          </div>
        </header>

        {apiKeyMissing && (
          <div className="bg-amber-500/10 border border-amber-500/20 text-amber-500 p-4 mx-6 mt-6 rounded-xl flex items-center justify-between">
            <div>
              <h3 className="font-bold mb-1">TMDB API Key Missing</h3>
              <p className="text-sm opacity-80">To fetch real movies and series, you need to provide a TMDB API Key. Please add VITE_TMDB_API_KEY to your .env file.</p>
            </div>
            <a href="https://developer.themoviedb.org/docs/getting-started" target="_blank" rel="noreferrer" className="bg-amber-500/20 px-4 py-2 rounded-lg text-sm font-bold hover:bg-amber-500/30 transition-colors">Get API Key</a>
          </div>
        )}

        {activeNav === 'Home' ? (
          <>
            {/* Hero Section */}
            <div 
              className="relative w-full h-[70vh] min-h-[500px] overflow-hidden"
              onMouseEnter={() => setIsHeroHovered(true)}
              onMouseLeave={() => setIsHeroHovered(false)}
            >
              <AnimatePresence>
                <motion.div 
                  key={`hero-bg-${heroAnime.id || heroIndex}`}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 1 }}
                  className="absolute inset-0 z-0"
                >
                  <img src={heroAnime.image} alt="Hero" className="w-full h-full object-cover opacity-60" />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#09090b] via-[#09090b]/50 to-transparent" />
                  <div className="absolute inset-0 bg-gradient-to-r from-[#09090b] via-[#09090b]/80 lg:via-[#09090b]/20 to-transparent" />
                </motion.div>
              </AnimatePresence>

              <div className="absolute bottom-0 left-0 w-full z-10 p-6 lg:p-12 pb-16 flex flex-col items-start max-w-4xl pointer-events-none">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={`hero-content-${heroAnime.id || heroIndex}`}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.5, ease: "easeInOut" }}
                    className="flex flex-col items-start"
                  >
                    <div className="flex gap-2 mb-4 pointer-events-auto">
                      {(heroAnime.tags || []).map((tag: string) => (
                        <span key={tag} className="px-3 py-1 text-[10px] uppercase tracking-widest font-bold rounded-sm bg-white/10 backdrop-blur-md text-zinc-300 border border-white/10">
                          {tag}
                        </span>
                      ))}
                    </div>
                    
                    <h1 className="text-5xl lg:text-7xl font-black tracking-tight mb-2 uppercase drop-shadow-lg pointer-events-auto">
                      {heroAnime.title}
                    </h1>

                    <p className="text-fuchsia-400 font-semibold tracking-wider text-sm mb-4 drop-shadow-md pointer-events-auto">
                      {heroAnime.subtitle}
                    </p>
                    
                    <p className="text-zinc-300 max-w-xl text-sm lg:text-base leading-relaxed mb-8 line-clamp-3 drop-shadow-md pointer-events-auto">
                      {heroAnime.description}
                    </p>

                    <div className="flex gap-4 items-center pointer-events-auto mb-4 lg:mb-0">
                      <button 
                        onClick={() => {
                          if (!library.find(item => item.title === heroAnime.title)) {
                            setLibrary([{
                              id: heroAnime.id || Math.random().toString(36).substr(2, 9),
                              title: heroAnime.title,
                              type: heroAnime.type || 'Series',
                              status: 'Watching',
                              currentSeason: 1,
                              currentEp: 1,
                              totalEps: heroAnime.totalEps,
                              image: heroAnime.image,
                              lastUpdated: "Just now",
                              description: heroAnime.description,
                              genres: heroAnime.tags
                            }, ...library]);
                          }
                          setActiveNav('My List');
                          setLibraryFilter('Watching');
                        }}
                        className="group flex items-center justify-center gap-2 bg-white text-black px-6 py-3.5 rounded-full font-bold hover:scale-105 transition-all w-48"
                      >
                        <Play className="w-5 h-5 fill-black group-hover:fill-fuchsia-600 transition-colors" />
                        Start Tracking
                      </button>
                      <button 
                        onClick={() => {
                          if (!library.find(item => item.title === heroAnime.title)) {
                            setLibrary([{
                              id: heroAnime.id || Math.random().toString(36).substr(2, 9),
                              title: heroAnime.title,
                              type: heroAnime.type || 'Series',
                              status: 'Plan to Watch',
                              currentSeason: 1,
                              currentEp: 0,
                              totalEps: heroAnime.totalEps,
                              image: heroAnime.image,
                              lastUpdated: "Just now",
                              description: heroAnime.description,
                              genres: heroAnime.tags
                            }, ...library]);
                            setActiveNav('My List');
                            setLibraryFilter('Plan to Watch');
                          } else {
                            setActiveNav('My List');
                          }
                        }}
                        className="flex items-center justify-center w-14 h-14 rounded-full glass-panel hover:bg-white/10 transition-all hover:scale-105 group relative"
                      >
                        {library.find(i => i.title === heroAnime.title) ? (
                          <Check className="w-6 h-6 text-green-400" />
                        ) : (
                          <Plus className="w-6 h-6 text-white" />
                        )}
                        <span className="absolute -top-10 scale-0 group-hover:scale-100 transition-transform bg-zinc-800 text-xs py-1 px-2 rounded font-medium whitespace-nowrap text-white">
                          {library.find(i => i.title === heroAnime.title) ? 'In Library' : 'Add to List'}
                        </span>
                      </button>
                    </div>
                  </motion.div>
                </AnimatePresence>
                
                {/* Carousel Navigation */}
                {heroAnimes.length > 1 && (
                  <div className="absolute right-6 bottom-16 lg:right-12 lg:bottom-16 flex items-center gap-4 pointer-events-auto">
                    <button 
                      onClick={(e) => {
                         e.stopPropagation();
                         setHeroIndex(prev =>(prev - 1 + heroAnimes.length) % heroAnimes.length);
                      }} 
                      className="w-10 h-10 rounded-full glass-panel flex justify-center items-center hover:bg-white/10 transition-colors"
                    >
                      <ChevronRight className="w-5 h-5 rotate-180" />
                    </button>
                    
                    <div className="flex gap-2 bg-black/40 px-3 py-2 rounded-full glass-panel">
                      {heroAnimes.map((_, idx) => (
                        <button
                          key={idx}
                          onClick={(e) => {
                            e.stopPropagation();
                            setHeroIndex(idx);
                          }}
                          className={`h-2 rounded-full transition-all duration-500 ease-in-out ${heroIndex === idx ? 'w-8 bg-fuchsia-500' : 'w-2 bg-white/30 hover:bg-white/60'}`}
                        />
                      ))}
                    </div>

                    <button 
                      onClick={(e) => {
                         e.stopPropagation();
                         setHeroIndex(prev =>(prev + 1) % heroAnimes.length);
                      }} 
                      className="w-10 h-10 rounded-full glass-panel flex justify-center items-center hover:bg-white/10 transition-colors"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Content sections */}
            <div className="px-6 lg:px-12 pb-24 flex flex-col gap-12 relative z-20 -mt-8">
              
              {/* Continue Watching */}
              <section>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold tracking-wide">Continue Watching</h2>
                  <button onClick={() => { setActiveNav('My List'); setLibraryFilter('Watching'); }} className="text-sm font-medium text-fuchsia-400 hover:text-fuchsia-300 flex items-center gap-1 group">
                    See all <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 hover:cursor-pointer">
                  {library.filter(i => i.status === 'Watching').slice(0, 4).map((item) => (
                    <div key={item.id} className="group relative rounded-2xl overflow-hidden glass-panel border border-white/5 p-4 flex gap-4 items-center transition-all hover:bg-white/5 hover:border-white/20">
                      <div className="relative w-32 h-20 md:w-40 md:h-28 rounded-xl overflow-hidden shrink-0 bg-white/5">
                        {item.image ? (
                           <img src={item.image} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                        ) : (
                           <div className="w-full h-full flex items-center justify-center text-zinc-600">
                              <Film className="w-8 h-8" />
                           </div>
                        )}
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <Play className="w-8 h-8 fill-white" />
                        </div>
                      </div>
                      <div className="flex-1 w-full min-w-0 pr-4">
                        <h3 className="font-bold text-base truncate mb-1">{item.title}</h3>
                        <p className="text-xs text-zinc-400 mb-3 truncate">
                          {item.type === 'Series' && <>S{item.currentSeason || 1} • </>}EP {item.currentEp} {item.totalEps ? `/ ${item.totalEps}` : ''}
                        </p>
                        
                        <div className="flex items-center gap-3">
                          <div className="flex-1 h-1.5 bg-black/50 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-gradient-to-r from-fuchsia-500 to-indigo-500 rounded-full transition-all" 
                              style={{ width: `${item.totalEps ? (item.currentEp / item.totalEps) * 100 : 70}%` }}
                            />
                          </div>
                          <button 
                            onClick={(e) => { e.stopPropagation(); updateItemProgress(item.id, item.currentEp + 1); }}
                            className="bg-white/10 hover:bg-white/20 w-8 h-8 rounded flex items-center justify-center text-zinc-300 hover:text-white transition-colors flex-shrink-0"
                            title="Increment Episode"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                  {library.filter(i => i.status === 'Watching').length === 0 && (
                     <div className="col-span-1 md:col-span-2 py-8 text-center text-zinc-500 glass-panel rounded-2xl border border-white/5">
                       <p>You aren't watching anything right now.</p>
                       <button onClick={() => { setActiveNav('My List'); setIsAddModalOpen(true); }} className="mt-2 text-fuchsia-400 hover:text-fuchsia-300 text-sm font-medium">Add something to your list</button>
                     </div>
                  )}
                </div>
              </section>

              {/* Top Anime Series */}
              {topAnimes.length > 0 && (
                <section>
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-bold tracking-wide">Top Anime Series</h2>
                    <div className="flex gap-2">
                    <button onClick={() => {
                        const el = document.getElementById('scroll-top-animes');
                        if (el) el.scrollBy({ left: -400, behavior: 'smooth' });
                      }} className="w-8 h-8 rounded-full glass-panel flex justify-center items-center hover:bg-white/10"><ChevronRight className="w-4 h-4 rotate-180" /></button>
                    <button onClick={() => {
                        const el = document.getElementById('scroll-top-animes');
                        if (el) el.scrollBy({ left: 400, behavior: 'smooth' });
                      }} className="w-8 h-8 rounded-full glass-panel flex justify-center items-center hover:bg-white/10"><ChevronRight className="w-4 h-4" /></button>
                  </div>
                </div>
                
                <div id="scroll-top-animes" className="flex gap-4 overflow-x-auto hide-scrollbar pb-4 -mx-6 px-6 lg:mx-0 lg:px-0">
                    {topAnimes.map((item) => (
                      <div 
                        key={item.id} 
                        className="relative group w-40 min-w-40 md:w-48 md:min-w-48 aspect-[2/3] rounded-2xl overflow-hidden cursor-pointer shrink-0"
                        onClick={() => setSelectedAnime(item)}
                      >
                        <img 
                          src={item.image} 
                          alt={item.title} 
                          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />
                        
                        <div className="absolute top-2 right-2 glass-panel px-2 py-1 flex items-center gap-1 rounded-md bg-black/40">
                          <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                          <span className="text-[10px] font-bold">{item.score}</span>
                        </div>

                        <div className="absolute bottom-4 left-4 right-4">
                          <h3 className="font-bold text-sm leading-tight text-white/90 group-hover:text-white transition-colors">{item.title}</h3>
                        </div>
                      </div>
                    ))}
                  </div>
                </section>
              )}

              {/* Trending */}
              <section>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold tracking-wide">Trending Now</h2>
                  <div className="flex gap-2">
                    <button onClick={() => {
                        const el = document.getElementById('scroll-trending');
                        if (el) el.scrollBy({ left: -400, behavior: 'smooth' });
                      }} className="w-8 h-8 rounded-full glass-panel flex justify-center items-center hover:bg-white/10"><ChevronRight className="w-4 h-4 rotate-180" /></button>
                    <button onClick={() => {
                        const el = document.getElementById('scroll-trending');
                        if (el) el.scrollBy({ left: 400, behavior: 'smooth' });
                      }} className="w-8 h-8 rounded-full glass-panel flex justify-center items-center hover:bg-white/10"><ChevronRight className="w-4 h-4" /></button>
                  </div>
                </div>
                
                <div id="scroll-trending" className="flex gap-4 overflow-x-auto hide-scrollbar pb-4 -mx-6 px-6 lg:mx-0 lg:px-0">
                  {trendingAnime.map((item) => (
                    <div 
                      key={item.id} 
                      className="relative group w-40 min-w-40 md:w-48 md:min-w-48 aspect-[2/3] rounded-2xl overflow-hidden cursor-pointer shrink-0"
                      onClick={() => setSelectedAnime(item)}
                    >
                      <img 
                        src={item.image} 
                        alt={item.title} 
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />
                      
                      <div className="absolute top-2 right-2 glass-panel px-2 py-1 flex items-center gap-1 rounded-md bg-black/40">
                        <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                        <span className="text-[10px] font-bold">{item.score}</span>
                      </div>

                      <div className="absolute bottom-4 left-4 right-4">
                        <h3 className="font-bold text-sm leading-tight text-white/90 group-hover:text-white transition-colors">{item.title}</h3>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              {/* Top Movies */}
              <section>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold tracking-wide">Top Movies</h2>
                  <div className="flex gap-2">
                    <button onClick={() => {
                        const el = document.getElementById('scroll-top-movies');
                        if (el) el.scrollBy({ left: -400, behavior: 'smooth' });
                      }} className="w-8 h-8 rounded-full glass-panel flex justify-center items-center hover:bg-white/10"><ChevronRight className="w-4 h-4 rotate-180" /></button>
                    <button onClick={() => {
                        const el = document.getElementById('scroll-top-movies');
                        if (el) el.scrollBy({ left: 400, behavior: 'smooth' });
                      }} className="w-8 h-8 rounded-full glass-panel flex justify-center items-center hover:bg-white/10"><ChevronRight className="w-4 h-4" /></button>
                  </div>
                </div>
                
                <div id="scroll-top-movies" className="flex gap-4 overflow-x-auto hide-scrollbar pb-4 -mx-6 px-6 lg:mx-0 lg:px-0">
                  {topMovies.map((item) => (
                    <div 
                      key={`movie-${item.id}`} 
                      className="relative group w-40 min-w-40 md:w-48 md:min-w-48 aspect-[2/3] rounded-2xl overflow-hidden cursor-pointer shrink-0"
                      onClick={() => setSelectedAnime(item)}
                    >
                      <img 
                        src={item.image} 
                        alt={item.title} 
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />
                      
                      <div className="absolute top-2 right-2 glass-panel px-2 py-1 flex items-center gap-1 rounded-md bg-black/40">
                        <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                        <span className="text-[10px] font-bold">{item.score}</span>
                      </div>

                      <div className="absolute bottom-4 left-4 right-4">
                        <h3 className="font-bold text-sm leading-tight text-white/90 group-hover:text-white transition-colors">{item.title}</h3>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              {/* Top Series */}
              <section>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold tracking-wide">Top Series</h2>
                  <div className="flex gap-2">
                    <button onClick={() => {
                        const el = document.getElementById('scroll-top-series');
                        if (el) el.scrollBy({ left: -400, behavior: 'smooth' });
                      }} className="w-8 h-8 rounded-full glass-panel flex justify-center items-center hover:bg-white/10"><ChevronRight className="w-4 h-4 rotate-180" /></button>
                    <button onClick={() => {
                        const el = document.getElementById('scroll-top-series');
                        if (el) el.scrollBy({ left: 400, behavior: 'smooth' });
                      }} className="w-8 h-8 rounded-full glass-panel flex justify-center items-center hover:bg-white/10"><ChevronRight className="w-4 h-4" /></button>
                  </div>
                </div>
                
                <div id="scroll-top-series" className="flex gap-4 overflow-x-auto hide-scrollbar pb-4 -mx-6 px-6 lg:mx-0 lg:px-0">
                  {topSeries.map((item) => (
                    <div 
                      key={`series-${item.id}`} 
                      className="relative group w-40 min-w-40 md:w-48 md:min-w-48 aspect-[2/3] rounded-2xl overflow-hidden cursor-pointer shrink-0"
                      onClick={() => setSelectedAnime(item)}
                    >
                      <img 
                        src={item.image} 
                        alt={item.title} 
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />
                      
                      <div className="absolute top-2 right-2 glass-panel px-2 py-1 flex items-center gap-1 rounded-md bg-black/40">
                        <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                        <span className="text-[10px] font-bold">{item.score}</span>
                      </div>

                      <div className="absolute bottom-4 left-4 right-4">
                        <h3 className="font-bold text-sm leading-tight text-white/90 group-hover:text-white transition-colors">{item.title}</h3>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              {/* Recommended Movies */}
              <section>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold tracking-wide">Recommended Movies</h2>
                  <div className="flex gap-2">
                    <button onClick={() => {
                        const el = document.getElementById('scroll-rec-movies');
                        if (el) el.scrollBy({ left: -400, behavior: 'smooth' });
                      }} className="w-8 h-8 rounded-full glass-panel flex justify-center items-center hover:bg-white/10"><ChevronRight className="w-4 h-4 rotate-180" /></button>
                    <button onClick={() => {
                        const el = document.getElementById('scroll-rec-movies');
                        if (el) el.scrollBy({ left: 400, behavior: 'smooth' });
                      }} className="w-8 h-8 rounded-full glass-panel flex justify-center items-center hover:bg-white/10"><ChevronRight className="w-4 h-4" /></button>
                  </div>
                </div>
                
                <div id="scroll-rec-movies" className="flex gap-4 overflow-x-auto hide-scrollbar pb-4 -mx-6 px-6 lg:mx-0 lg:px-0">
                  {recommendedMovies.map((item) => (
                    <div 
                      key={`recmovie-${item.id}`} 
                      className="relative group w-40 min-w-40 md:w-48 md:min-w-48 aspect-[2/3] rounded-2xl overflow-hidden cursor-pointer shrink-0"
                      onClick={() => setSelectedAnime(item)}
                    >
                      <img 
                        src={item.image} 
                        alt={item.title} 
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />
                      
                      <div className="absolute top-2 right-2 glass-panel px-2 py-1 flex items-center gap-1 rounded-md bg-black/40">
                        <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                        <span className="text-[10px] font-bold">{item.score}</span>
                      </div>

                      <div className="absolute bottom-4 left-4 right-4">
                        <h3 className="font-bold text-sm leading-tight text-white/90 group-hover:text-white transition-colors">{item.title}</h3>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              {/* Recommended Series */}
              <section>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold tracking-wide">Recommended Series</h2>
                  <div className="flex gap-2">
                    <button onClick={() => {
                        const el = document.getElementById('scroll-rec-series');
                        if (el) el.scrollBy({ left: -400, behavior: 'smooth' });
                      }} className="w-8 h-8 rounded-full glass-panel flex justify-center items-center hover:bg-white/10"><ChevronRight className="w-4 h-4 rotate-180" /></button>
                    <button onClick={() => {
                        const el = document.getElementById('scroll-rec-series');
                        if (el) el.scrollBy({ left: 400, behavior: 'smooth' });
                      }} className="w-8 h-8 rounded-full glass-panel flex justify-center items-center hover:bg-white/10"><ChevronRight className="w-4 h-4" /></button>
                  </div>
                </div>
                
                <div id="scroll-rec-series" className="flex gap-4 overflow-x-auto hide-scrollbar pb-4 -mx-6 px-6 lg:mx-0 lg:px-0">
                  {recommendedSeries.map((item) => (
                    <div 
                      key={`recseries-${item.id}`} 
                      className="relative group w-40 min-w-40 md:w-48 md:min-w-48 aspect-[2/3] rounded-2xl overflow-hidden cursor-pointer shrink-0"
                      onClick={() => setSelectedAnime(item)}
                    >
                      <img 
                        src={item.image} 
                        alt={item.title} 
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />
                      
                      <div className="absolute top-2 right-2 glass-panel px-2 py-1 flex items-center gap-1 rounded-md bg-black/40">
                        <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                        <span className="text-[10px] font-bold">{item.score}</span>
                      </div>

                      <div className="absolute bottom-4 left-4 right-4">
                        <h3 className="font-bold text-sm leading-tight text-white/90 group-hover:text-white transition-colors">{item.title}</h3>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            </div>
          </>
        ) : activeNav === 'My List' ? (
          <div className="px-4 lg:px-8 pt-24 pb-24 h-full flex flex-col relative z-20">
            {/* Library Header & Filters */}
            <div className="flex flex-col gap-6 mb-8 mt-2 items-center lg:items-start max-w-5xl mx-auto w-full">
              <div className="flex flex-col lg:flex-row gap-4 w-full justify-between items-start lg:items-center">
                {/* Filter Tabs using the design from the image */}
                <div className="glass-panel rounded-xl flex items-center gap-2 overflow-x-auto hide-scrollbar border border-white/5 w-full lg:w-auto flex-1">
                  {(['All', 'Watching', 'On-Hold', 'Completed', 'Plan to Watch'] as const).map(filter => {
                    const count = filter === 'All' ? library.length : library.filter(i => i.status === filter).length;
                    return (
                      <button
                        key={filter}
                        onClick={() => setLibraryFilter(filter)}
                        className={`flex-1 flex items-center justify-center gap-1.5 px-4 py-3 whitespace-nowrap text-sm font-medium transition-all ${
                          libraryFilter === filter 
                            ? 'bg-white/10 text-white border-b-2 border-fuchsia-500' 
                            : 'text-zinc-400 hover:bg-white/5 hover:text-white border-b-2 border-transparent'
                        }`}
                      >
                        {filter} 
                        <span className="text-zinc-500">
                          ({count})
                        </span>
                      </button>
                    );
                  })}
                </div>
                <button 
                  onClick={() => {
                    setIsBulkMode(!isBulkMode);
                    if (isBulkMode) setSelectedItems(new Set()); 
                  }}
                  className={`shrink-0 px-5 py-3 rounded-xl text-sm font-bold border transition-colors ${
                    isBulkMode || selectedItems.size > 0
                      ? 'bg-fuchsia-500 text-white border-fuchsia-500' 
                      : 'bg-white/5 text-zinc-300 border-white/10 hover:bg-white/10'
                  }`}
                >
                  {isBulkMode || selectedItems.size > 0 ? 'Done' : 'Select Items'}
                </button>
              </div>

              {availableGenres.length > 0 && (
                <div className="flex gap-3 w-full overflow-x-auto hide-scrollbar pb-4 pt-2">
                  <button
                    onClick={() => setGenreFilter('All')}
                    className={`relative px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-colors ${
                      genreFilter === 'All' 
                        ? 'text-white' 
                        : 'text-zinc-400 hover:text-white bg-white/5 hover:bg-white/10 border border-white/5'
                    }`}
                  >
                    {genreFilter === 'All' && (
                      <motion.div
                        layoutId="active-genre"
                        className="absolute inset-0 bg-fuchsia-600 rounded-full shadow-[0_0_15px_rgba(192,38,211,0.4)] border border-fuchsia-400/30"
                        transition={{ type: "spring", stiffness: 400, damping: 30 }}
                      />
                    )}
                    <span className="relative z-10 drop-shadow-sm">All Genres</span>
                  </button>
                  {availableGenres.map(genre => (
                    <button
                      key={genre}
                      onClick={() => setGenreFilter(genre)}
                      className={`relative px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-colors ${
                        genreFilter === genre
                          ? 'text-white' 
                          : 'text-zinc-400 hover:text-white bg-white/5 hover:bg-white/10 border border-white/5'
                      }`}
                    >
                      {genreFilter === genre && (
                        <motion.div
                          layoutId="active-genre"
                          className="absolute inset-0 bg-fuchsia-600 rounded-full shadow-[0_0_15px_rgba(192,38,211,0.4)] border border-fuchsia-400/30"
                          transition={{ type: "spring", stiffness: 400, damping: 30 }}
                        />
                      )}
                      <span className="relative z-10 drop-shadow-sm">{genre}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Library Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 max-w-5xl mx-auto w-full">
              <AnimatePresence mode='popLayout'>
                {filteredLibrary.map(item => {
                  const pct = item.totalEps ? (item.currentEp / item.totalEps) * 100 : 0;
                  return (
                    <motion.div
                      layout
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      transition={{ duration: 0.2 }}
                      key={item.id}
                      onClick={() => {
                        if (isBulkMode || selectedItems.size > 0) {
                          setSelectedItems(prev => {
                            const next = new Set(prev);
                            if (next.has(item.id)) next.delete(item.id);
                            else next.add(item.id);
                            return next;
                          });
                        } else {
                          setSelectedLibraryItem(item);
                          setActiveModalTab('Details');
                        }
                      }}
                      className={`glass-panel rounded-2xl p-5 border relative group hover:border-white/10 transition-colors cursor-pointer ${
                        selectedItems.has(item.id) 
                          ? 'border-fuchsia-500 bg-fuchsia-500/5' 
                          : 'border-white/5'
                      }`}
                    >
                      {/* Top Header of Card */}
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex gap-2 items-center">
                          {(isBulkMode || selectedItems.size > 0) && (
                            <div className={`w-5 h-5 rounded flex items-center justify-center border-2 transition-colors ${
                              selectedItems.has(item.id) 
                                ? 'bg-fuchsia-500 border-fuchsia-500' 
                                : 'border-zinc-500 bg-black/20'
                            }`}>
                              {selectedItems.has(item.id) && <Check className="w-3.5 h-3.5 text-white" />}
                            </div>
                          )}
                          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-white/5 text-[10px] font-bold text-zinc-300 uppercase tracking-wider border border-white/5 shadow-sm">
                            {item.type === 'Series' ? <MonitorPlay className="w-3 h-3" /> : <Film className="w-3 h-3" />}
                            {item.type}
                          </span>
                          <span className={`px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider border shadow-sm ${statusColors[item.status]}`}>
                            {item.status}
                          </span>
                        </div>
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          {(item.status === 'Watching' || item.status === 'Plan to Watch') && (
                            <button
                              onClick={(e) => { 
                                e.stopPropagation(); 
                                setLibrary(lib => lib.map(i => i.id === item.id ? { ...i, status: 'Completed', currentEp: i.totalEps || i.currentEp, lastUpdated: 'Just now' } : i)); 
                              }}
                              className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-green-500/20 text-zinc-400 hover:text-green-400 transition-colors"
                              title="Mark as Completed"
                            >
                              <CheckCheck className="w-4 h-4" />
                            </button>
                          )}
                          <button 
                            onClick={(e) => { e.stopPropagation(); /* edit logic */ }}
                            className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-white/10 text-zinc-400 hover:text-white transition-colors"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button 
                            onClick={(e) => { e.stopPropagation(); setLibrary(lib => lib.filter(i => i.id !== item.id)); }}
                            className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-red-500/20 text-zinc-400 hover:text-red-400 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <h3 className="text-xl font-bold mb-4">{item.title}</h3>

                      {/* Progress Area */}
                      <div className="mb-6">
                        <div className="flex text-sm items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="text-zinc-400 font-mono text-xs uppercase">
                              {item.type === 'Series' && <>S{item.currentSeason || 1}{item.totalSeasons ? `/${item.totalSeasons}` : ''} • </>}
                              EP <span className="text-white text-base font-bold">{item.currentEp}</span> / {item.totalEps || '?'}
                            </span>
                            {item.type === 'Series' && (
                              <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    updateItemProgress(item.id, item.currentEp + 1);
                                  }}
                                  title="Mark current episode as watched"
                                  className="ml-1 w-6 h-6 rounded-full bg-white/5 hover:bg-fuchsia-500/20 flex items-center justify-center text-zinc-400 hover:text-fuchsia-400 transition-colors border border-transparent hover:border-fuchsia-500/30"
                                >
                                    <Check className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                          {item.status === 'Watching' && item.type === 'Series' && (!item.totalEps || item.currentEp < item.totalEps) && (
                            <span className="text-[10px] text-fuchsia-400/80 font-medium whitespace-nowrap bg-fuchsia-400/10 px-2 py-0.5 rounded border border-fuchsia-400/20">
                              EST: {(() => {
                                const hash = item.id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0) + item.currentEp;
                                const daysToAdd = (hash % 7) + 1;
                                const date = new Date();
                                date.setDate(date.getDate() + daysToAdd);
                                return date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
                              })()}
                            </span>
                          )}
                        </div>
                        <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
                          <div className={`h-full ${statusIndicatorColors[item.status]} rounded-full transition-all duration-300`} style={{ width: `${pct}%` }} />
                        </div>
                      </div>

                      {/* Dropdown like 'Spin-offs & Movies' logic from image placeholder */}
                      {item.type === 'Series' && (
                         <div className="bg-white/5 border border-white/5 rounded-xl p-3 mb-6">
                            <div className="flex items-center gap-2 text-xs font-semibold text-zinc-300">
                               <Star className="w-3 h-3" /> Spin-offs & Movies
                            </div>
                         </div>
                      )}

                      <div className="flex items-center justify-between mt-auto">
                        <span className="text-xs text-zinc-500 flex items-center gap-1.5 opacity-50">
                          <Clock className="w-3 h-3" /> {item.lastUpdated}
                        </span>
                        {(item.status === 'Watching' || item.status === 'On-Hold') && (
                          <button 
                            onClick={(e) => e.stopPropagation()}
                            className="text-xs font-medium text-fuchsia-400 bg-fuchsia-400/10 px-3 py-1.5 rounded-lg border border-fuchsia-400/20 hover:bg-fuchsia-400/20 flex items-center gap-1.5 transition-colors"
                          >
                            <ExternalLink className="w-3 h-3" /> Resume {item.type === 'Series' ? `S${item.currentSeason || 1} • Ep ${item.currentEp}` : ''}
                          </button>
                        )}
                      </div>
                    </motion.div>
                  )
                })}
              </AnimatePresence>
              {filteredLibrary.length === 0 && (
                <div className="col-span-full py-20 flex flex-col items-center justify-center text-zinc-500">
                  <Library className="w-12 h-12 mb-4 opacity-20" />
                  <p>No items found in this category.</p>
                </div>
              )}
            </div>

            {/* Bulk Action Bar */}
            <AnimatePresence>
              {selectedItems.size > 0 && (
                <motion.div
                  initial={{ y: 100, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: 100, opacity: 0 }}
                  className="fixed bottom-24 lg:bottom-12 left-0 right-0 z-50 flex justify-center pointer-events-none px-4"
                >
                  <div className="glass-panel-heavy border border-white/10 rounded-2xl p-2 pl-6 flex items-center gap-6 shadow-2xl pointer-events-auto bg-black/80 backdrop-blur-2xl">
                    <span className="text-sm font-bold text-white">
                      {selectedItems.size} Selected
                    </span>
                    <div className="h-6 w-px bg-white/10" />
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          setLibrary(lib => lib.map(i => selectedItems.has(i.id) ? { ...i, status: 'Watching', lastUpdated: 'Just now' } : i));
                          setSelectedItems(new Set());
                          setIsBulkMode(false);
                        }}
                        className="px-4 py-2 rounded-xl bg-white/5 hover:bg-blue-500/20 hover:text-blue-400 text-sm font-bold transition-colors flex items-center gap-2"
                      >
                        <Play className="w-4 h-4" />
                        <span className="hidden sm:inline">Watching</span>
                      </button>
                      <button
                        onClick={() => {
                          setLibrary(lib => lib.map(i => selectedItems.has(i.id) ? { ...i, status: 'Completed', currentEp: i.totalEps || i.currentEp, lastUpdated: 'Just now' } : i));
                          setSelectedItems(new Set());
                          setIsBulkMode(false);
                        }}
                        className="px-4 py-2 rounded-xl bg-white/5 hover:bg-green-500/20 hover:text-green-400 text-sm font-bold transition-colors flex items-center gap-2"
                      >
                        <CheckCheck className="w-4 h-4" />
                        <span className="hidden sm:inline">Complete</span>
                      </button>
                      <button
                        onClick={() => {
                          setLibrary(lib => lib.map(i => selectedItems.has(i.id) ? { ...i, status: 'On-Hold', lastUpdated: 'Just now' } : i));
                          setSelectedItems(new Set());
                          setIsBulkMode(false);
                        }}
                        className="px-4 py-2 rounded-xl bg-white/5 hover:bg-yellow-500/20 hover:text-yellow-400 text-sm font-bold transition-colors flex items-center gap-2"
                      >
                        <Clock className="w-4 h-4" />
                        <span className="hidden sm:inline">On-Hold</span>
                      </button>
                      <button
                        onClick={() => {
                          setLibrary(lib => lib.filter(i => !selectedItems.has(i.id)));
                          setSelectedItems(new Set());
                          setIsBulkMode(false);
                        }}
                        className="px-4 py-2 rounded-xl bg-white/5 hover:bg-red-500/20 hover:text-red-400 text-sm font-bold transition-colors flex items-center gap-2"
                      >
                        <Trash2 className="w-4 h-4" />
                        <span className="hidden sm:inline">Delete</span>
                      </button>
                      <button
                        onClick={() => {
                          setSelectedItems(new Set());
                          setIsBulkMode(false);
                        }}
                        className="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-sm font-bold transition-colors ml-2"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ) : activeNav === 'Settings' ? (
          <div className="px-4 lg:px-8 py-6 h-full flex flex-col relative z-20">
            <div className="max-w-2xl mx-auto w-full">
              <h2 className="text-3xl font-black tracking-tight mb-8">Settings</h2>
              
              <div className="glass-panel p-8 rounded-3xl border border-white/5 space-y-8">
                <div>
                  <h3 className="text-xl font-bold mb-4">Profile Information</h3>
                  <div className="flex flex-col sm:flex-row gap-6 items-start">
                    <img 
                      src={userProfile.avatar} 
                      alt="Profile" 
                      className="w-24 h-24 rounded-full object-cover border-2 border-white/10"
                    />
                    <div className="flex-1 space-y-4 w-full">
                      <div>
                        <label className="block text-xs font-semibold text-zinc-400 mb-2 uppercase tracking-wider">Username</label>
                        <input 
                          type="text" 
                          value={userProfile.name}
                          onChange={(e) => setUserProfile({...userProfile, name: e.target.value})}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-fuchsia-500 transition-colors"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-zinc-400 mb-2 uppercase tracking-wider">Avatar Image URL</label>
                        <input 
                          type="text" 
                          value={userProfile.avatar}
                          onChange={(e) => setUserProfile({...userProfile, avatar: e.target.value})}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-fuchsia-500 transition-colors"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="border-t border-white/5 pt-8">
                   <h3 className="text-xl font-bold mb-4">Account Preferences</h3>
                   <div className="space-y-4">
                      <div className="flex items-center justify-between bg-white/5 p-4 rounded-xl border border-white/5">
                        <div>
                          <p className="font-bold">Dark Mode</p>
                          <p className="text-sm text-zinc-400">By default, NEXA revolves around an immersive dark environment.</p>
                        </div>
                        <div className="w-10 h-6 bg-fuchsia-500 rounded-full flex items-center p-1 justify-end shadow-[0_0_10px_rgba(217,70,239,0.5)]">
                           <div className="w-4 h-4 bg-white rounded-full"></div>
                        </div>
                      </div>
                   </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-center h-full text-zinc-500">
            <p>Select Home or My Library</p>
          </div>
        )}
      </main>

      <AnimatePresence>
        {selectedLibraryItem && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
            onClick={() => setSelectedLibraryItem(null)}
          >
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-[#121216] w-full max-w-2xl max-h-[90vh] rounded-3xl overflow-hidden shadow-2xl flex flex-col relative outline outline-1 outline-white/10"
            >
              {/* Close btn */}
              <button 
                onClick={() => setSelectedLibraryItem(null)}
                className="absolute top-4 right-4 z-20 w-8 h-8 flex items-center justify-center rounded-full bg-black/40 backdrop-blur hover:bg-white/20 transition text-zinc-300"
              >
                <X className="w-4 h-4" />
              </button>

              {selectedLibraryItem.image && (
                <div className="w-full h-56 md:h-72 relative shrink-0">
                  <img src={selectedLibraryItem.image} className="w-full h-full object-cover opacity-70" alt={selectedLibraryItem.title} />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#121216] via-[#121216]/50 to-transparent block" />
                </div>
              )}

              <div className={`flex-1 flex flex-col justify-start overflow-y-auto ${!selectedLibraryItem.image ? 'pt-12 p-8 md:p-10' : 'p-8 md:p-10 -mt-20 z-10'}`}>
                <div className="flex flex-wrap gap-2 mb-4">
                   <div className={`px-2.5 py-1 rounded-md text-xs font-bold border ${statusColors[selectedLibraryItem.status]}`}>
                     {selectedLibraryItem.status}
                   </div>
                   <div className="px-2.5 py-1 rounded-md bg-white/5 text-xs font-bold text-zinc-300 border border-white/10 backdrop-blur">
                     {selectedLibraryItem.type}
                   </div>
                   {(selectedLibraryItem.releaseDate) && (
                   <div className="px-2.5 py-1 rounded-md bg-white/5 text-xs font-bold text-zinc-300 border border-white/10 backdrop-blur">
                     {selectedLibraryItem.releaseDate}
                   </div>
                   )}
                </div>

                <h2 className="text-3xl md:text-5xl font-black mb-3 uppercase leading-none tracking-tight text-white drop-shadow-md">
                  {selectedLibraryItem.title}
                </h2>
                
                <div className="flex flex-wrap gap-2.5 mb-6">
                  {(selectedLibraryItem.genres || []).map(g => (
                    <span key={g} className="text-[11px] uppercase tracking-wider text-fuchsia-300 font-bold bg-fuchsia-500/10 px-2 py-1 rounded-md border border-fuchsia-500/20">{g}</span>
                  ))}
                </div>

                {/* Tabs */}
                <div className="flex gap-6 border-b border-white/5 mb-6">
                  <button onClick={() => setActiveModalTab('Details')} className={`pb-3 font-semibold text-sm transition-colors ${activeModalTab === 'Details' ? 'text-white border-b-2 border-fuchsia-500' : 'text-zinc-500 hover:text-zinc-300'}`}>Details</button>
                  <button onClick={() => setActiveModalTab('History')} className={`pb-3 font-semibold text-sm transition-colors ${activeModalTab === 'History' ? 'text-white border-b-2 border-fuchsia-500' : 'text-zinc-500 hover:text-zinc-300'}`}>History</button>
                </div>

                {activeModalTab === 'Details' ? (
                  <>
                    <p className="text-zinc-300 text-sm md:text-base leading-relaxed mb-8">
                      {selectedLibraryItem.description || "No synopsis available for this item."}
                    </p>

                    <div className="mt-auto bg-white/5 p-5 md:p-6 rounded-2xl border border-white/5 backdrop-blur-md">
                       <div className="flex justify-between items-end mb-3">
                         <div className="flex flex-col">
                            <span className="text-zinc-400 font-semibold text-xs uppercase tracking-wider mb-1">Your Progress</span>
                            <div className="flex items-center gap-3">
                               <span className="text-white text-2xl font-black">{selectedLibraryItem.currentEp} <span className="text-zinc-500 text-lg font-medium">/ {selectedLibraryItem.totalEps || '?'} EP</span></span>
                            </div>
                         </div>
                         <button 
                            onClick={() => updateItemProgress(selectedLibraryItem.id, selectedLibraryItem.currentEp + 1)}
                            className="bg-fuchsia-600 hover:bg-fuchsia-500 text-white rounded-xl px-4 py-2 font-bold text-sm transition-colors flex items-center gap-2"
                         >
                           <Plus className="w-4 h-4" /> Log Episode
                         </button>
                       </div>
                       <div className="h-2 w-full bg-black/50 rounded-full overflow-hidden">
                          <div 
                            className={`h-full ${statusIndicatorColors[selectedLibraryItem.status]} rounded-full transition-all duration-500`} 
                            style={{ width: `${selectedLibraryItem.totalEps ? (selectedLibraryItem.currentEp / selectedLibraryItem.totalEps) * 100 : 0}%` }} 
                          />
                       </div>
                    </div>
                  </>
                ) : (
                  <div className="flex-1 overflow-y-auto pr-2 pb-2">
                    {(!selectedLibraryItem.history || selectedLibraryItem.history.length === 0) ? (
                      <p className="text-zinc-500 italic text-sm">No watch history available yet. Log an episode to see it here.</p>
                    ) : (
                      <div className="flex flex-col gap-3">
                        {selectedLibraryItem.history.map((h, i) => (
                           <div key={i} className="flex justify-between items-center bg-white/5 rounded-xl p-4 border border-white/5 transition-colors hover:bg-white/10">
                             <div className="flex items-center gap-4">
                               <div className="w-10 h-10 rounded-full bg-fuchsia-500/20 text-fuchsia-400 flex items-center justify-center font-bold text-sm border border-fuchsia-500/30">
                                 {h.ep}
                               </div>
                               <div>
                                 <p className="text-white font-bold text-sm">Watched Episode {h.ep}</p>
                                 <p className="text-zinc-400 text-xs mt-0.5">{new Date(h.date).toLocaleDateString()} at {new Date(h.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</p>
                               </div>
                             </div>
                             <Check className="w-5 h-5 text-green-400 drop-shadow-[0_0_5px_rgba(74,222,128,0.5)]" />
                           </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- ADD MODAL --- */}
      <AnimatePresence>
        {isAddModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="bg-[#121216] w-full max-w-md rounded-3xl overflow-hidden shadow-2xl border border-white/10 flex flex-col"
            >
              <div className="flex justify-between items-center p-6 border-b border-white/5">
                <h3 className="font-bold text-lg">Track New Item</h3>
                <button 
                  onClick={() => setIsAddModalOpen(false)}
                  className="w-8 h-8 rounded-full flex items-center justify-center bg-white/5 hover:bg-white/10 transition-colors text-zinc-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              
              <form onSubmit={handleAddItem} className="p-6 flex flex-col gap-6">
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 mb-2 uppercase tracking-wider">Title</label>
                  <input 
                    type="text" 
                    required
                    placeholder="e.g. Naruto Shippuden"
                    value={newItemParams.title || ''}
                    onChange={(e) => setNewItemParams({...newItemParams, title: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-fuchsia-500 transition-colors"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-zinc-400 mb-2 uppercase tracking-wider">Type</label>
                    <select 
                      value={newItemParams.type}
                      onChange={(e) => setNewItemParams({...newItemParams, type: e.target.value as TrackType})}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-fuchsia-500 transition-colors appearance-none"
                    >
                      <option value="Series">Series</option>
                      <option value="Movie">Movie</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-zinc-400 mb-2 uppercase tracking-wider">Status</label>
                    <select 
                      value={newItemParams.status}
                      onChange={(e) => setNewItemParams({...newItemParams, status: e.target.value as TrackStatus})}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-fuchsia-500 transition-colors appearance-none"
                    >
                      <option value="Watching">Watching</option>
                      <option value="Plan to Watch">Plan to Watch</option>
                      <option value="Completed">Completed</option>
                      <option value="On-Hold">On-Hold</option>
                    </select>
                  </div>
                </div>

                {newItemParams.type === 'Series' && (
                  <div className="grid grid-cols-2 gap-4">
                     <div>
                        <label className="block text-xs font-semibold text-zinc-400 mb-2 uppercase tracking-wider">Current Season</label>
                        <input 
                          type="number" min="1" 
                          value={newItemParams.currentSeason || ''}
                          onChange={(e) => setNewItemParams({...newItemParams, currentSeason: parseInt(e.target.value) || 1})}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-fuchsia-500 transition-colors"
                        />
                     </div>
                     <div>
                        <label className="block text-xs font-semibold text-zinc-400 mb-2 uppercase tracking-wider">Total Seasons</label>
                        <input 
                          type="number" min="1" placeholder="Optional"
                          value={newItemParams.totalSeasons || ''}
                          onChange={(e) => setNewItemParams({...newItemParams, totalSeasons: parseInt(e.target.value) || undefined})}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-fuchsia-500 transition-colors"
                        />
                     </div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                   <div>
                      <label className="block text-xs font-semibold text-zinc-400 mb-2 uppercase tracking-wider">Current Ep.</label>
                      <input 
                        type="number" min="0" 
                        value={newItemParams.currentEp || 0}
                        onChange={(e) => setNewItemParams({...newItemParams, currentEp: parseInt(e.target.value) || 0})}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-fuchsia-500 transition-colors"
                      />
                   </div>
                   <div>
                      <label className="block text-xs font-semibold text-zinc-400 mb-2 uppercase tracking-wider">Total Ep.</label>
                      <input 
                        type="number" min="1" placeholder="Optional"
                        value={newItemParams.totalEps || ''}
                        onChange={(e) => setNewItemParams({...newItemParams, totalEps: parseInt(e.target.value) || undefined})}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-fuchsia-500 transition-colors"
                      />
                   </div>
                </div>

                <div className="mt-4 flex gap-3">
                  <button 
                    type="button"
                    onClick={() => setIsAddModalOpen(false)}
                    className="flex-1 py-3.5 rounded-xl font-bold bg-white/5 hover:bg-white/10 text-white transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="flex-1 py-3.5 rounded-xl font-bold bg-fuchsia-600 hover:bg-fuchsia-500 text-white transition-colors"
                  >
                    Add to Tracker
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- DETAILS OVERLAY --- */}
      <AnimatePresence>
        {selectedAnime && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
            onClick={() => setSelectedAnime(null)}
          >
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-[#121216] w-full max-w-4xl max-h-[90vh] rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row relative outline outline-1 outline-white/10"
            >
              {/* Close btn */}
              <button 
                onClick={() => setSelectedAnime(null)}
                className="absolute top-4 right-4 z-20 w-8 h-8 flex items-center justify-center rounded-full bg-black/40 backdrop-blur hover:bg-white/20 transition text-zinc-300"
              >
                <Plus className="w-5 h-5 rotate-45" />
              </button>

              <div className="w-full md:w-5/12 h-64 md:h-auto relative">
                <img src={selectedAnime.image} className="w-full h-full object-cover" alt={selectedAnime.title} />
                <div className="absolute inset-0 bg-gradient-to-t md:bg-gradient-to-r from-[#121216] to-transparent block" />
              </div>

              <div className="flex-1 p-8 md:p-10 flex flex-col justify-center overflow-y-auto">
                <div className="flex gap-2 mb-3 mt-auto">
                   <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-white/10 text-xs font-bold text-fuchsia-400">
                     <Star className="w-3.5 h-3.5 fill-fuchsia-400" />
                     {selectedAnime.rating || selectedAnime.score || "9.5"}
                   </div>
                   <div className="px-2.5 py-1 rounded-md bg-white/5 text-xs font-bold text-zinc-400 border border-white/5">
                     TV Series
                   </div>
                   <div className="px-2.5 py-1 rounded-md bg-white/5 text-xs font-bold text-zinc-400 border border-white/5">
                     Fall 2024
                   </div>
                </div>

                <h2 className="text-3xl md:text-5xl font-black mb-4 uppercase leading-none tracking-tight">
                  {selectedAnime.title}
                </h2>

                <p className="text-zinc-400 text-sm leading-relaxed mb-8">
                  {selectedAnime.description || "A visually stunning masterpiece that pushes the boundaries of modern animation. Follow the journey through a complex narrative filled with breathtaking action and deep emotional resonance."}
                </p>

                <div className="flex flex-wrap gap-4 mt-auto">
                  <button 
                    onClick={() => {
                      if (!selectedAnime) return;
                      if (!library.find(item => item.title === selectedAnime.title)) {
                        setLibrary([{
                          id: Math.random().toString(36).substr(2, 9),
                          title: selectedAnime.title,
                          type: 'Series',
                          status: 'Watching',
                          currentSeason: 1,
                          currentEp: 1,
                          image: selectedAnime.image,
                          lastUpdated: "Just now"
                        }, ...library]);
                      }
                      setSelectedAnime(null);
                      setActiveNav('My List');
                      setLibraryFilter('Watching');
                    }}
                    className="flex-1 min-w-[200px] flex items-center justify-center gap-2 bg-gradient-to-r from-fuchsia-600 to-indigo-600 text-white px-6 py-3.5 rounded-full font-bold hover:shadow-lg hover:shadow-fuchsia-600/30 transition-all hover:scale-[1.02]">
                    <Play className="w-5 h-5 fill-white" />
                    Start Tracking
                  </button>
                  <button 
                    onClick={() => {
                      if (!selectedAnime) return;
                      if (!library.find(item => item.title === selectedAnime.title)) {
                        setLibrary([{
                          id: Math.random().toString(36).substr(2, 9),
                          title: selectedAnime.title,
                          type: 'Series',
                          status: 'Plan to Watch',
                          currentSeason: 1,
                          currentEp: 0,
                          image: selectedAnime.image,
                          lastUpdated: "Just now"
                        }, ...library]);
                      }
                      setSelectedAnime(null);
                      setActiveNav('My List');
                      setLibraryFilter('Plan to Watch');
                    }}
                    className="w-14 h-14 rounded-full flex items-center justify-center bg-white/10 hover:bg-white/20 transition-colors border border-white/5 relative group"
                  >
                    {library.find(i => i.title === selectedAnime.title) ? (
                      <Check className="w-6 h-6 text-green-400" />
                    ) : (
                      <Plus className="w-6 h-6 text-zinc-200" />
                    )}
                    <span className="absolute -top-10 scale-0 group-hover:scale-100 transition-transform bg-zinc-800 text-xs py-1 px-2 rounded font-medium whitespace-nowrap">
                      {library.find(i => i.title === selectedAnime.title) ? 'In Library' : 'Add to List'}
                    </span>
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mobile Bottom Nav */}
      <nav className="glass-panel-heavy lg:hidden fixed bottom-0 left-0 right-0 z-40 border-t border-white/10 flex justify-between items-center px-6 py-4 pb-safe pb-6">
        <MobileNavItem icon={<Home />} label="Home" isActive={activeNav === 'Home'} onClick={() => setActiveNav('Home')} />
        <MobileNavItem icon={<Library />} label="Library" isActive={activeNav === 'My List'} onClick={() => setActiveNav('My List')} />
        <MobileNavItem icon={<Settings />} label="Settings" isActive={activeNav === 'Settings'} onClick={() => setActiveNav('Settings')} />
      </nav>

    </div>
  );
}

// Subcomponents

function NavItem({ icon, label, isActive, onClick }: { icon: React.ReactNode, label: string, isActive: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`group flex items-center xl:w-full gap-4 p-3 xl:px-4 rounded-xl transition-all duration-300 relative ${isActive ? 'bg-fuchsia-500/10 text-fuchsia-400' : 'text-zinc-400 hover:text-zinc-100 hover:bg-white/5'}`}
    >
      <div className="relative">
        <div className={`transition-transform duration-300 ${isActive ? 'scale-110' : 'group-hover:scale-110'}`}>
          {icon}
        </div>
      </div>
      <span className={`hidden xl:block font-medium ${isActive ? 'text-fuchsia-400 font-semibold' : ''}`}>{label}</span>
      {isActive && (
        <motion.div 
          layoutId="nav-indicator"
          className="absolute left-0 top-[10%] bottom-[10%] w-1 bg-fuchsia-500 rounded-r-lg"
        />
      )}
    </button>
  );
}

function MobileNavItem({ icon, label, isActive, onClick }: { icon: React.ReactNode, label: string, isActive: boolean, onClick: () => void }) {
  return (
    <button onClick={onClick} className="flex flex-col items-center gap-1.5 min-w-[64px]">
      <div className={`transition-all duration-300 ${isActive ? 'text-fuchsia-400 scale-110' : 'text-zinc-400'}`}>
        {icon}
      </div>
      {isActive && <div className="w-1 h-1 rounded-full bg-fuchsia-400" />}
    </button>
  );
}
